<template>
 <div class="flex justify-evenly content-center items-center bg-black text-white py-4">
   <div class="site-logo">
     <h1 class="text-3xl text-red-900 font-extrabold"> The Movies </h1>
   </div>
    <ul class="inline-flex">
      <li class="px-4 text-xl hover:text-red-900 transition delay-150"> <NuxtLink to="/"> Latest</NuxtLink></li>
      <li class="px-4 text-xl hover:text-red-900 transition delay-150"> <NuxtLink to="/">Movies</NuxtLink></li>
      <li class="px-4 text-xl hover:text-red-900 transition delay-150"> <NuxtLink to="/"> Upcoming</NuxtLink></li>
      <li class="px-4 text-xl hover:text-red-900 transition delay-150"> <NuxtLink to="/">Trending </NuxtLink></li>
    </ul>
  </div> 

  <!-- <div class="bg-header-img bg-cover bg-center w-full bg-no-repeat h-96">
    <div class="content p-20">
      <h1 class="text-3xl  font-bold text-red-900"> Latest movies </h1>
      <h1 class="text-9xl p-5 text-white"> <strong>Now</strong> Streaming</h1>
      <div class="btn btn-blue inline-block"> Views Movies</div>
    </div>
  </div> -->
</template>

<style>
  .btn {
    @apply font-bold py-2 px-4 rounded;
  }

  .btn-blue {
    @apply bg-red-900 text-white;
  }

  .btn-blue:hover {
    @apply bg-white text-black;
  }
</style>