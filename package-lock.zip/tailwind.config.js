const { lineHeight } = require('tailwindcss/defaulttheme');

module.exports = {
  content: [
    "./components/**/*.{js,vue,ts}",
    "./layouts/**/*.vue",
    "./pages/**/*.vue",
    "./plugins/**/*.{js,ts}",
    "./nuxt.config.{js,ts}",
  ],
  
  theme: {
    fontFamily: {
      sans: ['Graphik', 'sans-serif'],
      serif: ['Merriweather', 'serif'],
    },
    
    extend: {
      backgroundImage: {
        'header-img': "url('~/assets/img/film-70638.jpg')",
      },
      
      gridTemplateColumns: {
        'header' : '500px 2fr',
      },

      lineHeight: {
        '12':'4rem',
      }
    },
    color: {
      'midnight': '#181615',
    }
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}
