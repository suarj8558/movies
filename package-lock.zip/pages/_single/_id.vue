<template>
  <div class="single__movie container mx-auto">
    <div class="heading"> 
      <h2 class="heading text-center text-3xl p-9 font-bold">{{movie.title}}</h2>
    </div>
    <NuxtLink to="/" class="bg-red-900 hover:bg-black font-bold text-white px-3 p-2 rounded"> Back </NuxtLink>
    <div class="trailer mt-10" v-if="video.results">
      <h2 class="font-bold text-3xl px-0 py-3"> Watch Trailers </h2>
      <iframe class="w-full" height="600" :src="`https://www.youtube.com/embed/${video.results.at(0).key}`" title="YouTube video player" frameborder="0" allow="accelerometer;   autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
      </iframe>
    </div>
    
    <div class="grid grid-cols-2 gap-x-1 my-4">
      <div class="hero-img mx-auto">
        <img :src="`https://image.tmdb.org/t/p/w500/${movie.poster_path}`"  :alt="movie.original_title">
      </div>
      <div class="details text-2xl leading-12">
        <h2> <strong>Movie Name : </strong>{{movie.original_title}}</h2>
        <p><strong> Release Date : </strong>  {{movie.release_date}}</p>
        <p> <strong>People Likes : </strong>{{movie.popularity}}</p>
        <p><strong> Productions By</strong> {{movie.production_companies.name}}</p>
        <p><strong>Movie budget : </strong> <strong>Rs.</strong> {{movie.budget}}</p>
        <p><strong> Movie Revenue : </strong> <strong>Rs.</strong> {{movie.revenue}}</p>
        <p><strong> Vote Average : </strong>  {{ movie.vote_average}}</p>
        <p> <strong>Overview : </strong>{{movie.overview}}</p>
      </div>
    </div>
  </div>

</template>

<script>
// import Trailers from '~/components/Trailers.vue';
export default {

  async asyncData({ $axios,params}) {
    var mivieid = params.id;
    let data = await $axios.$get(`https://api.themoviedb.org/3/movie/${mivieid}?api_key=e9b397668e65893b94474842234d2947&language=en-US`);
    let videos = await $axios.$get(`https://api.themoviedb.org/3/movie/${mivieid}/videos?api_key=e9b397668e65893b94474842234d2947&language=en-US`);

    console.log(videos);
    return {
      movie : data,
      video : videos
    }
  },

  data() {
    return {
      id: this.$route.params.id,
    }
  },
  components: {
    // Trailers
  }
}
</script>

<style>

</style>