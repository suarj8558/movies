<template>
  <div class="container mx-auto">
    <!-- movie search bar -->
    <div class="mt-5 flex justify-around">
     <form action="" class="w-full">
       <input v-on:keyup="searchMovie()" type="text" placeholder="Search your Movies" name="search" class="rounded w-4/5" v-model="searchInput" > 
     </form> 
   </div>
    <!-- show movies list  -->
    <div class="grid grid-cols-1  sm:grid-cols-4 gap-6 mt-5" v-if="data.results">
      <Movies
        v-for="(data, dataIndex) in data.results"
        :key="dataIndex" 
        :movieData="data" 
      />
      <!-- <pre>
        {{this.show_page? show_page:'no data'}}
      </pre> -->
    </div> 
    <div class="pagination flex justify-between my-2"> 
      <!-- <button @click="preview()" class="px-8 rounded-full bg-black text-white"> Preview </button> -->
      <NuxtLink  v-if="current_page > 1" class="px-8 rounded-full bg-black text-white" :to="`?page=${current_page == 1 ? current_page : (current_page - 1)}`">Preview</NuxtLink>
        <div class="pagenumber  inline-block">
          <pre v-html="$router.params" />
        </div>
      <!-- <button @click="pagination()" class="px-8 rounded-full bg-black text-white"> pagenumber </button> -->
      <NuxtLink class="px-8 rounded-full bg-black text-white" :to="`?page=${Number( current_page) + 1}`"> Next </NuxtLink>
    </div>
    <pre>
      {{no_of_data}}
    </pre>
  </div>
</template>

<script>
import Trailers from '~/components/Trailers.vue';
import Movies from '~/components/Movies.vue';

export default {
  data() {
    return {
      movies: [],
      searchInput: this.$route.query.search,
      current_page: this.$route.query.page ? this.$route.query.page : 1,
      per_page : 4,
    }
  },

  watchQuery: true,

  async asyncData({ $axios, query }) {
    let current_page = query.page ? query.page : 1;
    
    let movies = await $axios.$get(`https://api.themoviedb.org/3/trending/movie/day?api_key=e9b397668e65893b94474842234d2947&page=${current_page}`);
    
    return { 
      data: movies,
    }
    
  },
 
  methods:{
    async searchMovie () {
      if(this.searchInput == '') return

      const search = await this.$axios.$get(`https://api.themoviedb.org/3/search/movie?api_key=e9b397668e65893b94474842234d2947&language=en-US&query=${this.searchInput}&page=${this.current_page}&include_adult=false`);
  
      if( search.results.length > 0 ) {
        this.data = search
      } 
    },  
  },
 
  components : {
    Trailers,
    Movies
  }
}
</script>
