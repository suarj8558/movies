<template>
  <div class="container mx-auto">
    <!-- movie search bar -->
    <div class="mt-5 flex justify-around">
     <form action="" class="w-full">
       <input v-on:keyup="searchMovie()" type="text" placeholder="Search your Movies" name="search" class="rounded w-4/5" v-model="searchInput" > 
     </form> 
   </div>
    <!-- show movies list  -->
    <div class="grid grid-cols-1  sm:grid-cols-4 gap-6 mt-5" v-if="data.results">
      <Movies
        v-for="(data, dataIndex) in data.results"
        :key="dataIndex" 
        :movieData="data" 
      />
      <pre>
        {{datalength ? 'data' :'no data'}}
      </pre>
    </div> 
    <div class="pagination flex justify-between my-2" v-html="datalength"> 
      <button @click="preview()" class="px-8 rounded-full bg-black text-white"> Preview </button>
        <div class="pagenumber py-4  inline-block"> 1</div>
      <button  @click="next()" class="px-8 rounded-full bg-black text-white"> Next </button>
    </div>
    <!-- <pre>
      {{number_of_page}}
    </pre> -->
  </div>
</template>

<script>
import Trailers from '~/components/Trailers.vue';
import Movies from '~/components/Movies.vue';

export default {
   data() {
    return {
      movies: [],
      searchInput: '',
      current_page: 1,
      per_page : 8,
      datalength:null,
      number_of_page: null
    }
  },

  async asyncData({ $axios }) {
    let movies = await $axios.$get('https://api.themoviedb.org/3/trending/movie/day?api_key=e9b397668e65893b94474842234d2947');
    return { 
      data: movies,
    }
  },

  methods:{
    async searchMovie() {
      if(this.searchInput == '') return

      const data = this.$axios.$get(`https://api.themoviedb.org/3/search/movie?api_key=e9b397668e65893b94474842234d2947&language=en-US&query=${this.searchInput}&page=1&include_adult=false`);
      const search = await data
      this.datalength = this.data.results.length ;
      if( search.results.length > 0 ) this.data = search
    },

   
    // async next() {
    //   this.datalength = this.data.results.length ; 
    //   if(datalength > 10){
    //     console.log(datalength);
    //   }
    //   else {
    //     console.log('page less then 10');
    //   }
      
    // },
    //  async Page_Number(datalength, per_page){

    //   const number_of_page = Math.ceil(datalength / per_page);

    // },

    async preview() {
      console.log(' preview button call ');
    },
  },
 
  components : {
    Trailers,
    Movies
  }
}
</script>
