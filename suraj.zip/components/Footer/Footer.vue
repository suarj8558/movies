<template>
  <div class="text-center p-2 bg-black mt-5"> 
    <h2 class="text-white">	&#169; copy right 2022</h2>
  </div>
</template>