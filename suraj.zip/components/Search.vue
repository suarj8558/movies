<template>
   <div class="mt-5 flex justify-around">
     <form action="" class="w-full">
       <input type="text" placeholder="Search Movies" name="search" class="rounded w-4/5"> 
       <button class="bg-red-900 hover:bg-red-800 text-white p-2 px-4 rounded "><strong>Search</strong></button>
     </form> 
   </div>

</template>